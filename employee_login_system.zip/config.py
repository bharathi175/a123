
# config.py
EMAIL_ADDRESS = "your_email@gmail.com"         # Your Gmail
EMAIL_PASSWORD = "your_app_password_here"      # 16-digit app password
